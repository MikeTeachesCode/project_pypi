# README.md

- This is a super simple file management module for Python.